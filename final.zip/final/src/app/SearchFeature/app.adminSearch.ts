
import { User } from "../models/User";
import { CapStoreSearchService } from "../Services/app.CapStoreSearchService";
import { Merchant } from "../models/merchant";






export class adminSearchComponent{
    mr:Merchant;
    us:User;
    constructor(private service:CapStoreSearchService){}
    merchantId:number;
    userId:number;
    ch=false;
    change()
    {
        this.ch=true;
    }



findMerchantById()
    {
          this.service.findMerchant(this.merchantId).subscribe(res=>this.mr=res,err=>alert("an error has occured"))
    }

findUserById()
    {
          this.service.findUser(this.merchantId).subscribe(res=>this.us=res,err=>alert("an error has occured"))
    }



}