import { Component,OnInit} from "@angular/core";
import {ProductSingleService} from '../Services/showSingleProductService';
import {Product} from '../models/Product';
import {Observable} from 'rxjs';

@Component({
    selector:'show-wishlist',
    templateUrl:'app.wishlist.html'
})

export class ShowWishlist implements OnInit{

    constructor(private service:ProductSingleService){}
    products: Observable<Product[]>;

    product:Product;
    
    
    pid: string;
    uid: string;
    ngOnInit(): void {
        this.pid = sessionStorage.getItem('productId')
        this.uid = sessionStorage.getItem("user")  
       this.service.displayWishlist(this.uid).subscribe( res=>{
        this.products=res

     },
     err=>{
         alert("your wishlist is empty")
     })     
    }
    addToCart(index:number){
       let productId = this.products[index].productID;
        this.service.addCart(productId,this.uid);
    }
    removeFromWishlist(index:number){
        let productId = this.products[index].productID
        
    this.service.deleteFromWishlist(productId,this.uid)
    window.location.reload();
    }
   
   
} 