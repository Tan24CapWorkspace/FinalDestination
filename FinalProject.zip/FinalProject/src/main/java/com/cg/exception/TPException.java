package com.cg.exception;

public class TPException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TPException(String message) {
		super(message);
	}
	
}
