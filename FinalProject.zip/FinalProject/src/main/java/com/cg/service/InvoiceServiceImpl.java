package com.cg.service;



import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Invoice;
import com.cg.bean.Product;
import com.cg.bean.Transaction;
import com.cg.bean.User1;
import com.cg.dao.InvoiceJpaDao1;
import com.cg.dao.ProductDAO1;
import com.cg.dao.TransactionDAO1;
import com.cg.dao.TransactionJPADAO1;
import com.cg.dao.User1DAO1;
import com.cg.model.InvoiceProductModel;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

	Invoice invoice;

	InvoiceProductModel invoiceProductModelObject;

	@Autowired
	private ProductDAO1 productDao;

	@Autowired
	private User1DAO1 user1Dao;

	@Autowired
	InvoiceJpaDao1 invoiceJpaDao;

	@Autowired
	private TransactionDAO1 transactionDao;

	@Autowired
	private TransactionJPADAO1 transactionJPADao;

	@Transactional
	public InvoiceProductModel showInvoice(int orderid) {

		Integer userid = user1Dao.user(orderid).get(0).getUserId();
		String firstname = user1Dao.user(orderid).get(0).getFirstName();
		String lastname = user1Dao.user(orderid).get(0).getLastName();
		Long mobileno = user1Dao.user(orderid).get(0).getMobileNo();
		String emailid = user1Dao.user(orderid).get(0).getEmailid();
		List<Integer[]> product = transactionDao.getTransaction(orderid).getProducts();
		List<Integer[]> product1 = new ArrayList<Integer[]>();
		product1.addAll(product);
		Date dateofpurchanse = transactionDao.dateorder(orderid);
		Double total = 0.0;
		Product pro = new Product();
		List<Product> productsList = new ArrayList<>();
		for (Integer[] productDetails : product) {
			total = total + productDetails[2] * productDetails[1];
			pro = productDao.getProduct(productDetails[0]);
			productsList.add(pro);
		}

		invoice = new Invoice(userid, firstname, lastname, mobileno, emailid, product1, total, dateofpurchanse);
		invoiceProductModelObject = new InvoiceProductModel(invoice, productsList);
		invoiceJpaDao.saveAndFlush(invoice);

		return invoiceProductModelObject;
	}

	@Override
	public User1 getUser(int userid) {
		return user1Dao.getUser(userid);
	}

	@Override
	public void saveTransaction(Transaction transactionObject) {
		transactionJPADao.save(transactionObject);

	}

	@Override
	public Transaction showTransaction(int orderid) {
		return transactionJPADao.getOne(orderid);
	}

}
