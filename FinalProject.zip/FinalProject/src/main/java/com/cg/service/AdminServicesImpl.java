package com.cg.service;



import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.cg.dao.DiscountDAO;

import com.cg.dao.MerchantDAO;
import com.cg.dao.ProductDAO;
import com.cg.dao.PromocodeDAO;
import com.cg.dao.TPMerchantDao;
import com.cg.dao.User1DAO;
import com.cg.exception.ApplicationException;
import com.cg.exception.ProductNotFoundException;
import com.cg.exception.TPException;
import com.cg.service.Cryptography;
import com.cg.bean.Discount;
import com.cg.bean.Merchant;
import com.cg.bean.Product;

import com.cg.bean.Promocode;
import com.cg.bean.User1;





@Service
@Transactional
public class AdminServicesImpl implements AdminServices {
	


//---------------------------------------------------------------------Discount----------------------------------------------------------------------------------------------------------------	---------------
	@Autowired
	private DiscountDAO discountDAO;

	// To add new Discount into existing records
	@Override
	@Transactional
	public Discount addDiscount(Discount discount) {
		
		return discountDAO.save(discount);
	}
	
	
	// To remove discount by discount-id from existing records
	@Override
	@Transactional
	public void removeDiscount(int discountId) {
		Discount d=discountDAO.findById(discountId).get();
		if(d==null)
		{
			throw new ApplicationException ("Discount not Found For Deletion");
		}
		else {
			 discountDAO.deleteById(discountId) ;
		   }
		}
	
	// To get all discount Records
	@Override
	@Transactional
	public List<Discount> AllDiscounts() {
		List<Discount> discounts = discountDAO.findAll();
		if(discounts==null)
		{
			throw new ApplicationException ("Discount Records not Found ");
		}
		else
		{
		return discounts;
		}
	}

	//To find particular discount by discountId
	@Override
	public Discount findDiscount(int discountId) {
		Discount d=discountDAO.findById(discountId).get();
		if(d==null)
		{
			throw new ApplicationException ("Discount not Found");
		}
		else {
			  return d ;
		   }
		
	}
 
	//To update existing discount record removing previous one with new discountId
	@Override
	public void updateDiscount(Discount discount) {
		// TODO Auto-generated method stub
		Discount d=discountDAO.findById(discount.getDiscountId()).get();
		if(d==null)
		{
			throw new ApplicationException ("Discount not Found for Updation");
		}
		else {
			 discountDAO.deleteById(discount.getDiscountId()) ;
			 discountDAO.save(discount);
		   }
		}
	
	//Required for discount Module======================================================================================================================
	
	@Autowired
	private ProductDAO productDAO;
	@Override
	public List<Product> AllProducts() {
		// TODO Auto-generated method stub
		
		return productDAO.findAll();
	}


	@Override
	public Product findProduct(int productId) {
		// TODO Auto-generated method stub
		return productDAO.findById(productId).get();
	}
	
	
	//Required for discount Module=======================================================================================================================
	
	
	
//------------------------------------------------------------------------------------------------------User----------------------------------------------------------------------------------------------------

	@Autowired
    private User1DAO userDAO;

	@Override
	public List<User1>AllUsers() {
		// TODO Auto-generated method stub
		
		return userDAO.findAll() ;
	}
	
	@Override
	@Transactional
	public void removeUser(int userId) {
		
		 userDAO.deleteById(userId);
	}
	
	
//--------------------------------------------------------------------------------------------------Merchant---------------------------------------------------------------------------------------------------
	
		

		
		
		
		
		Cryptography c=new Cryptography();
		String secretKey="SomeSecretKey";
			@Autowired
			MerchantDAO dao;

			@Transactional(propagation = Propagation.REQUIRED)
			public void addMerchant(Merchant merchantObject) {

				if (dao.existsByEmailId(merchantObject.getEmailid()) != null) {
					throw new ApplicationException("Merchant Already exists!!");
				}
				String encyptedPassword=c.encrypt(merchantObject.getPassword(),secretKey);
				merchantObject.setPassword(encyptedPassword);
				dao.save(merchantObject);
			}
			
			

			public void removeMerchant(Merchant merchantobject) {
				// TODO Auto-generated method stub
				dao.delete(merchantobject);
			}

			public Merchant findMerchantById(Integer merchantId) {
				// TODO Auto-generated method stub
				return dao.findById(merchantId).get();
			}

			public List<Merchant> getAllMerchant() {
				// TODO Auto-generated method stub
				return dao.findAll();
			}

			public void updateMerchant(Merchant merchantObject) {
				// TODO Auto-generated method stub
				if (dao.existsByEmailId(merchantObject.getEmailid()) != null) {
					dao.save(merchantObject);
					
				}else {
					throw new ApplicationException("Merchant Not Found for update operation");

				}
			}

			public Merchant findMerchantByEmail(String merchantEmailId) {
				// TODO Auto-generated method stub
				return dao.existsByEmailId(merchantEmailId);
			}

//-------------------------------------------------------------------Product--------------------------------------------------------------------------------------------------------------------------------------
		

		
			@Autowired
			private MerchantDAO merchantRepo;
			
			@Autowired
			private ProductDAO productRepo;
			
			//@Autowired
			private Product product;
			
			//@Autowired
			private Merchant merchant;
			

			

			@Override
			public Merchant getMerchantById(int merchantId) {
				Optional<Merchant> box = merchantRepo.findById(merchantId);
				if(box.isPresent()) {
					Merchant merchant = box.get();
					return merchant;
				}else {
					return null;
				}
				
//				Merchant merchant = merchantRepo.getOne(merchantId);
//				merchant.setPassword(Base64Coder.decodeString(merchant.getPassword()));
//				return merchant;
			}

			@Override
			public Integer addProduct(Product product) throws ProductNotFoundException {
				try {
					System.out.println(product);
					productRepo.saveAndFlush(product);
					return product.getProductID();
				}catch(Exception e) {
					e.printStackTrace();
					return 0;
				}
			}
			
			@Override
			public List<Product> getAllProducts() {
				List<Product> list = productRepo.findAll();
				
				return list;
			}

			

			@Override
			public void updateProduct(Product product) throws ProductNotFoundException {
				Optional<Product> box = productRepo.findById(product.getProductID());
				if(box.isPresent()) {
					System.out.println(product);
					productRepo.save(product);
				}else {
					throw new ProductNotFoundException("product not found");
				}
			}

			@Override
			public Product getProductDetails(int productId) throws ProductNotFoundException{
				Optional<Product> box = productRepo.findById(product.getProductID());
				if(box.isPresent()) {
					System.out.println("in service");
					return box.get();
				}else {
					throw new ProductNotFoundException("product not found");
				}
			}

			@Override
			public void removeProduct(int productId) throws ProductNotFoundException {
				Optional<Product> box = productRepo.findById(product.getProductID());
				if(box.isPresent()) {
					productRepo.delete(box.get());
				}else {
					throw new ProductNotFoundException("product not found");
				}
			}

		

		
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	

	
//--------------------------------------------------------------------------------------------Promocode----------------------------------------------------------------------------------------------------------
		@Autowired
		PromocodeDAO promoDao;
		
		@Override
		public void addPromo(Promocode promo) {
			// TODO Auto-generated method stub
			promoDao.save(promo);	
			
		}

		@Override
		public List<Promocode> getAllPromos() {
			// TODO Auto-generated method stub
			return promoDao.findAll();
		}


		@Transactional(propagation = Propagation.REQUIRED)
		public void deletePromo(int id) {
			// TODO Auto-generated method stub
			if (promoDao.existsById(id)) {
		         promoDao.deleteById(id);
			} else {
				System.out.println("Id not found");
			}
		}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
//------------------------------------------------------ThirdPartyMerchant-------------------------------------------------------------------------------
		
		
		
		@Transactional(readOnly=true)
		@Override
		public List<Product> getAllTpproduct() {
			// TODO Auto-generated method stub
			if(productDAO.findAll().isEmpty()) {
				throw new TPException("No Product Exists");
			}
			return productDAO.findAll();
		}

		@Transactional
		@Override
		public String addTpProduct(Product p) {
			// TODO Auto-generated method stub
			productDAO.save(p);
				return "Product added";
		}

		@Transactional(propagation = Propagation.REQUIRED)
		public String update(int id, Product t) {
			Product m;
			Optional<Product> p = productDAO.findById(id);
			if (p.isPresent())
				m = p.get();
			else
				throw new TPException("Product doesn't exist"); // throwing custom exception if account doesn't exist
			
			m.setProductName(t.getProductName());
			m.setTag(t.getTag());
			m.setCompany(t.getCompany());
			m.setPhoto(t.getPhoto());
			m.setDescription(t.getDescription());
			m.setQuantity(t.getQuantity());
			m.setCategory(t.getCategory());
			m.setSubcategory(t.getSubcategory());
			m.setSoldQuantities(t.getSoldQuantities());
			m.setPrice(t.getPrice());
			m.setReleaseDate(t.getReleaseDate());
			
			return "Third Party Merchant updated";
		}
		
		@Autowired
		TPMerchantDao tpdao;
		
		@Transactional(readOnly=true)
		@Override
		public List<Merchant> getAllTpmerchant() {
			// TODO Auto-generated method stub
			if(dao.findAll().isEmpty()) {
				throw new TPException("No Third Party Merchant Exist");
			}
			return tpdao.findTPMerchant("Disapproved");
		}

		@Transactional(propagation = Propagation.REQUIRED)
		public String update(int id, Merchant t) {
			Merchant m;
			Optional<Merchant> p = tpdao.findById(id);
			if (p.isPresent())
				m = p.get();
			else
				throw new TPException("Merchant doesn't exist"); // throwing custom exception if account doesn't exist
			
//			dao.delete(a);
//			dao.save(account);
			
			m.setFirstName(t.getFirstName());
			m.setLastName(t.getLastName());
			m.setCompany(t.getCompany());
			m.setEmailid(t.getEmailid());
			m.setMobileno(t.getMobileno());
			m.setStatus(t.getStatus());
			return "Third Party Merchant updated";
		}

		/*@Transactional
		@Override
		public String delete(int merchantId) {
			// TODO Auto-generated method stub
			dao.deleteById(merchantId);
			return "Third Party Merchant deleted";
		}*/

		@Transactional
		@Override
		public String addAccount(Merchant t) {
			// TODO Auto-generated method stub
				tpdao.save(t);
				return "Third Party Merchant added";
		}
		
//---------------------------------------------------------------------------------------------------------------------------
	
}
